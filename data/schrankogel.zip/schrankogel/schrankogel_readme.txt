Data collected by Krystof Chytry and his colleagues from the Unviersity of Vienna. https://www.mountainresearch.at/microclim/

It comprises 857 plots located on a single mountain with multiple topographic and temperature predictors.

Species composition is published along with this publication: https://nsojournals.onlinelibrary.wiley.com/doi/10.1111/ecog.06744
Soil and temperature data are published along the master thesis of Ruth Falkenhahn (BOKU 2024, Vienna).